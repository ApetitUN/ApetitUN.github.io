
function timeline(){
    var JSONtext = JSON.stringify(hot3.getSourceData());
    document.getElementById("p1").innerHTML = JSONtext;
}
